#!/usr/bin/env python
"""Test:
      Get firmware version via MKHI
   Procedure:
      1. Open default device
      2. Connect to the MKHI client
      3. Request version
      4. Sleep 1 sec (if requested)
      5. Read response and check version length
      6. Close the connection
"""
import os, time
import unittest
import mei
import mei.mkhi
from mei.debugfs import fixed_address

class GetVersionBaseTestCase(unittest.TestCase):
    def setUp(self):
        self.fd = mei.open_dev_default()
        try:
            mei.connect(self.fd, self.UUID)
        except IOError as e:
            if e.errno == 25:
                print "Errro: Cannot find MKHI Client"
                exit(1)
            else:
                raise e

    def tearDown(self):
        os.close(self.fd)

    def cmpsize(self, timeout=0):
        mei.mkhi.req_ver(self.fd)
        if timeout:
            time.sleep(timeout)
        buf = mei.mkhi.get_ver_raw(self.fd)
        self.assertEqual(len(buf), 28)

    def test_cmpsize(self):
        self.cmpsize()

    def test_cmpsize_sleep(self):
        self.cmpsize(1)

    def test_cmpsize_twice(self):
        self.cmpsize()
        self.cmpsize()

class GetVersionTestCase(GetVersionBaseTestCase):
    def __init__(self, methodName='runTest'):
        GetVersionBaseTestCase.__init__(self, methodName)
        self.UUID = mei.mkhi.UUID

class GetVersionFixedTestCase(GetVersionBaseTestCase):

    def __init__(self, methodName='runTest'):
        GetVersionBaseTestCase.__init__(self, methodName)
        self.UUID = mei.mkhi.FIXED_UUID

    @classmethod
    def setUpClass(cls):
        cls.devnode = mei.dev_default()
        try:
            fixed_address(cls.devnode, True)
        except Exception as e:
             print "Errro: cannot enable fixed address"
             raise e

    @classmethod
    def tearDownClass(cls):
        fixed_address(cls.devnode, False)

if __name__ == '__main__':
    suite = unittest.TestLoader().loadTestsFromTestCase(GetVersionTestCase)
    unittest.TextTestRunner(verbosity=2).run(suite)
    suite = unittest.TestLoader().loadTestsFromTestCase(GetVersionFixedTestCase)
    unittest.TextTestRunner(verbosity=2).run(suite)

