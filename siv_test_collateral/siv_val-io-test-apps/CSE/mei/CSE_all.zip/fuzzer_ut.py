#!/usr/bin/env python
"""Test:
      Stress clients
   Procedure:
      1. Open default device
      2. Connect to the client
      3. Send data
      4. Close the connection
"""
import os
import unittest
import mei
import fuzzer
import mei.mkhi
import mei.pavp

class MaxlenStressTestCase(unittest.TestCase):
    uuid = ''
    niter = 1
    def runTest(self):
        for i in range(self.niter):
            fd = mei.open_dev_default()
            maxlen, ver = mei.connect(fd, self.uuid)
            fuzzer.write_random_len(fd, maxlen)
            os.close(fd)

class OneByteStressTestCase(unittest.TestCase):
    uuid = ''
    niter = 1
    def runTest(self):
        for i in range(self.niter):
            fd = mei.open_dev_default()
            maxlen, ver = mei.connect(fd, self.uuid)
            fuzzer.write_random_len(fd, 1)
            os.close(fd)

def generateTS(name, base, niter):
    '''generate test suite'''

    uuids = {'mkhi': mei.mkhi.UUID, 'pavp': mei.pavp.UUID}
    stressTS = unittest.TestSuite()

    for n, u in uuids.iteritems():
        test = type("%s:%s:%d" % (name, n, niter), (base,), {'uuid' : u, 'niter' : niter})()
        stressTS.addTest(test)

    return stressTS

if __name__ == '__main__':

    tsMaxLen = generateTS("MaxlenStressTestCase", MaxlenStressTestCase, 10)
    tsOneByte = generateTS("OneByteStressTestCase", OneByteStressTestCase, 100)
    tsAll = unittest.TestSuite([tsMaxLen, tsOneByte])
    unittest.TextTestRunner(verbosity=2).run(tsAll)

# vim:set sw=4 ts=4 et:
# -*- coding: utf-8 -*-

