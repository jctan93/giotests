#!/usr/bin/env python
"""Test:
      stress_max.py [<UUID>] - send MTU sized buffer to a firmware client in loop
   Procedure:
      1. Check connetion to supplied or first firemware client
      2. stress tests in loop (2000)
         2.1 open
         2.2 connect
         2.3. write a MTU sized buffer
         2.4. close
"""
"Send data rapidly to ME clients"
import os, sys
import mei
from mei.debugfs import meclients_dyn

def stress_write(fd, uuid_str, data):
    for n in range(0, 2000):
        fd = mei.open_dev_default()
        maxlen, vers = mei.connect(fd, uuid_str)
        os.write(fd, data)
        os.close(fd)

def main():
    uuid_str = None
    try:
        uuid_str = sys.argv[1]
    except IndexError as e:
        devnode = mei.dev_default()
        uuid_str = meclients_dyn(devnode)[0]['UUID']

    fd = mei.open_dev_default()
    try:
        maxlen, vers = mei.connect(fd, uuid_str)
    except IOError as e:
        if e.errno == 25:
            print "Errro: Cannot find Client"
            exit(1)
        else:
            raise e
    os.close(fd)

    stress_write(fd, uuid_str, "A" * maxlen)

if __name__ == '__main__':
    main()

