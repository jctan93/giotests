#!/bin/sh
for test  in *_ut.py; do
	echo ${test}
	sudo ./${test}
done
