#!/usr/bin/python

"""pavp helper functions for mei driver"""

UUID = 'fbf6fcf1-96cf-4e2e-a6a6-1bab8cbe36b1'
UUID_WIDI = 'b638ab7e-94e2-4ea2-a552-d1c54b627f04'
