#!/usr/bin/python

"""hotham helper functions for mei driver"""

UUID = '082ee5a7-7c25-470a-9643-0c06f0466ea1'
