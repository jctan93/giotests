#!/usr/bin/python

"""fwu helper functions for mei driver"""

UUID = '309dcde8-ccb1-4062-8f78-600115a34327'
