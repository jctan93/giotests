#!/usr/bin/python

"""cls helper functions for mei driver"""

UUID = 'f908627d-13bf-4a04-b91f-a64e9245323d'
