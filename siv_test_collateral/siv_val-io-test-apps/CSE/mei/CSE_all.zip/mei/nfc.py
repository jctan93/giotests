#!/usr/bin/python

"""nfc helper functions for mei driver"""

UUID = '27b961db-3057-49bb-bd0d-aca9fd8ff697'
UUID_INFO = 'd2de1625-382d-417d-48a4-efabba8a1206'
