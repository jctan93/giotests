#!/usr/bin/python

"""dal helper functions for mei driver"""

UUID_IVM  = '3c4852d6-d47b-4f46-b05e-b5edc1aa440e'
UUID_SDM  = 'dba4d603-d7ed-4931-8823-17ad585705d5'
UUID_LNCH = '5565a099-7fe2-45c1-a22b-d7e9dfea9a2e'
