#!/bin/sh
for test  in *.py; do
	sudo ./${test}
done
